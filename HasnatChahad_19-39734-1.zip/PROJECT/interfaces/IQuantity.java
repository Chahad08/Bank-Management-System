package interfaces;

import java.lang.*;
public interface IQuantity
{
	boolean addQuantity(int amount);
    boolean sellQuantity(int amount);
}